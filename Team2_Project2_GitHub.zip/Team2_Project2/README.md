# MTH321 Project 2 Final Submission

Team 2: Sirui Li (2141723), Yuxuan Li (2363599), Yuran Zhou (2363402), and Yazhi Xue (2255842).

## Submission contents

- `report/Team2_Project2_Report.pdf`: 19-page final report, including the AI Transparency Log and one labelled ICS page per member.
- `slides/Team2_Project2_Slides.pdf`: 12-slide presentation PDF for submission.
- `slides/Team2_Project2_Presentation.pptx`: editable PowerPoint source with speaker notes.
- `code/`: portable Python source, generated tables and figures, dependency list, and code-specific README.

## Reproduce the numerical evidence

From this directory:

```text
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r code/requirements.txt
python code/run_all.py
```

On macOS or Linux, activate with `source .venv/bin/activate`.

The final command regenerates both CSV tables and all five report figures, then validates the expected mesh levels, row counts, GMRES status flags, and monotone residual reduction.

## Final human checks before submission

1. Each member should review and approve their completed ICS wording. Typed electronic signatures and the date `2026-11-05` are included on the four labelled pages.
2. Verify each ICS contribution against the team's actual git history and add the repository commit ID wherever the course portal requests it.
3. Confirm the scheduled presentation wave and upload the slides PDF, report PDF, and code ZIP to the correct fields.
