"""
Linear solvers: sparse direct and an asymmetric Krylov iterative method.

The assembled matrix is generally nonsymmetric (boundary rows scale like h^-1
while interior PDE rows scale like h^-2), so conjugate gradient is not valid.
GMRES is used for the iterative path because it accepts a residual tolerance,
which is required for the tighten-residual experiment.
"""

import numpy as np
from scipy.sparse.linalg import LinearOperator, gmres, spilu, spsolve


def solve_direct(A, b):
    """Sparse direct solve (no tolerance parameter)."""
    return spsolve(A, b)


def build_preconditioner(A, drop_tol=1e-5, fill_factor=10):
    """Incomplete-LU preconditioner as a scipy LinearOperator."""
    ilu = spilu(A.tocsc(), drop_tol=drop_tol, fill_factor=fill_factor)
    return LinearOperator(A.shape, matvec=lambda v: ilu.solve(v))


def solve_iter(A, b, rtol, M=None, maxiter=10000):
    """GMRES solve, optionally with preconditioner M.

    Returns solution, iteration count and scipy info flag.
    """
    counter = {"n": 0}

    def callback(_xk):
        counter["n"] += 1

    x, info = gmres(A, b, rtol=rtol, M=M, maxiter=maxiter,
                    callback=callback, callback_type="legacy")
    return x, counter["n"], info


def relative_residual(A, b, x):
    """Achieved scaled residual ||b - A x|| / ||b||."""
    return np.linalg.norm(b - A @ x) / np.linalg.norm(b)
