"""
Four-mesh refinement study (h, h/2, h/4, h/8) using the sparse direct solver.

Reports discrete L2 and nodal L^inf errors with fitted observed orders,
and the matrix asymmetry measure on the finest mesh. Saves a CSV summary.
"""

import csv
import os

import numpy as np
from scipy.sparse.linalg import norm as sparse_norm

from assembler import assemble
from errors import l2_error, linf_error, observed_order, to_grid
from problem import make_grid
from solvers import solve_direct

NS = [8, 16, 32, 64]
COMBOS = [
    ("neumann", "first"),
    ("neumann", "ghost"),
    ("robin", "first"),
    ("robin", "ghost"),
]

records = []

for boundary, closure in COMBOS:
    print("=" * 78)
    print(f"{boundary.upper()} / {closure}-order closure")
    print("-" * 78)
    print(f"{'N':>4} {'h':>10} {'L2 error':>12} {'p(L2)':>7} {'Linf error':>12} {'p(Linf)':>8}")

    l2_vals, li_vals = [], []
    for N in NS:
        h, X, Y = make_grid(N)
        A, b = assemble(N, boundary=boundary, closure=closure)
        u = solve_direct(A, b)
        U = to_grid(u, N)
        e2 = l2_error(U, X, Y, h)
        ei = linf_error(U, X, Y)
        l2_vals.append(e2)
        li_vals.append(ei)
        p2 = observed_order(l2_vals[-2], e2) if len(l2_vals) > 1 else float("nan")
        pi = observed_order(li_vals[-2], ei) if len(li_vals) > 1 else float("nan")
        print(f"{N:>4} {h:>10.5f} {e2:>12.4e} {p2:>7.2f} {ei:>12.4e} {pi:>8.2f}")
        records.append([boundary, closure, N, h, e2, p2, ei, pi])

    # Matrix asymmetry on the finest mesh.
    Af, _ = assemble(NS[-1], boundary=boundary, closure=closure)
    # Keep the diagnostic sparse so the verification workflow scales beyond
    # the small meshes used in this report.
    asym = sparse_norm(Af - Af.T) / sparse_norm(Af)
    print(f"matrix asymmetry ||A-A^T||/||A|| at N={NS[-1]}: {asym:.4e}")
    print()

out = os.path.join(os.path.dirname(__file__), "refinement_table.csv")
with open(out, "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["boundary", "closure", "N", "h", "L2_error", "p_L2", "Linf_error", "p_Linf"])
    w.writerows(records)
print("Saved:", out)
