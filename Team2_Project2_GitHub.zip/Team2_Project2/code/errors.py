"""
Error norms and convergence-order fitting.

Nodal L^inf norm and a discrete L^2 norm with cell-area weight h^2.
"""

import numpy as np

from problem import u_exact


def to_grid(u, N):
    """Reshape a flat solution (k = j*(N+1)+i) into U[i,j]."""
    return u.reshape(N + 1, N + 1).T


def linf_error(U, X, Y):
    """Nodal maximum-norm error."""
    return float(np.max(np.abs(U - u_exact(X, Y))))


def l2_error(U, X, Y, h):
    """Discrete L2 error with unit cell-area weight h^2."""
    return float(h * np.sqrt(np.sum((U - u_exact(X, Y)) ** 2)))


def observed_order(e_coarse, e_fine):
    """Order inferred from two successive levels with refinement factor 2."""
    return float(np.log(e_coarse / e_fine) / np.log(2.0))
