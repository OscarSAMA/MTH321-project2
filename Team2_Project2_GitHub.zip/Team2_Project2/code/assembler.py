"""
Sparse assembly for the mixed-boundary Poisson problem.

Two boundary data variants on the right edge (x=1):
    * Neumann:  d_n u = q
    * Robin:    d_n u + beta u = r

Two boundary closures:
    * 'first': one-sided first-order row that replaces the PDE row.
    * 'ghost': second-order ghost-point closure; the ghost value is eliminated
               and the five-point equation is imposed on the boundary node.

Dirichlet nodes are imposed strongly (identity row). Known Dirichlet
contributions from neighbouring nodes are moved to the right-hand side.
"""

import numpy as np
from scipy import sparse

from problem import (
    BETA,
    dirichlet_value,
    forcing,
    is_dirichlet,
    neumann_flux,
    node_index,
    robin_rhs,
)


def assemble(N, boundary="neumann", closure="first"):
    """Return sparse matrix A (CSR) and right-hand side vector b."""
    if boundary not in ("neumann", "robin"):
        raise ValueError("boundary must be 'neumann' or 'robin'")
    if closure not in ("first", "ghost"):
        raise ValueError("closure must be 'first' or 'ghost'")

    h = 1.0 / N
    n_nodes = (N + 1) ** 2
    rows, cols, vals = [], [], []
    b = np.zeros(n_nodes)

    def put(r, c, v):
        rows.append(r)
        cols.append(c)
        vals.append(v)

    def place(r, i, j, coeff):
        """Place coefficient of neighbour (i,j); fold Dirichlet data into b."""
        if is_dirichlet(i, j, N):
            g = dirichlet_value(i * h, j * h)
            b[r] += -coeff * g
        else:
            put(r, node_index(i, j, N), coeff)

    for i in range(N + 1):
        for j in range(N + 1):
            r = node_index(i, j, N)

            # Dirichlet node: strong identity row.
            if is_dirichlet(i, j, N):
                put(r, r, 1.0)
                b[r] = dirichlet_value(i * h, j * h)
                continue

            # Interior free node: standard five-point stencil.
            if i < N:
                put(r, r, 4.0 / h**2)
                place(r, i - 1, j, -1.0 / h**2)  # west
                place(r, i + 1, j, -1.0 / h**2)  # east
                place(r, i, j - 1, -1.0 / h**2)  # south
                place(r, i, j + 1, -1.0 / h**2)  # north
                b[r] += forcing(i * h, j * h)
                continue

            # Right-edge free node (i = N, 1 <= j <= N-1).
            y = j * h
            if boundary == "neumann":
                q = neumann_flux(y)
                if closure == "first":
                    # (u_N - u_{N-1})/h = q
                    put(r, r, 1.0 / h)
                    place(r, N - 1, j, -1.0 / h)
                    b[r] += q
                else:
                    # ghost eliminated: (4u_N - 2u_{N-1} - u_S - u_N)/h^2
                    #                  = f + 2q/h
                    put(r, r, 4.0 / h**2)
                    place(r, N - 1, j, -2.0 / h**2)
                    place(r, N, j - 1, -1.0 / h**2)
                    place(r, N, j + 1, -1.0 / h**2)
                    b[r] += forcing(1.0, y) + 2.0 * q / h
            else:  # Robin
                rr = robin_rhs(y)
                if closure == "first":
                    # (u_N - u_{N-1})/h + beta u_N = r
                    put(r, r, 1.0 / h + BETA)
                    place(r, N - 1, j, -1.0 / h)
                    b[r] += rr
                else:
                    # ghost eliminated:
                    # u_N (4/h^2 + 2 beta/h) - 2/h^2 u_{N-1}
                    #   - 1/h^2 u_S - 1/h^2 u_N = f + 2r/h
                    put(r, r, 4.0 / h**2 + 2.0 * BETA / h)
                    place(r, N - 1, j, -2.0 / h**2)
                    place(r, N, j - 1, -1.0 / h**2)
                    place(r, N, j + 1, -1.0 / h**2)
                    b[r] += forcing(1.0, y) + 2.0 * rr / h

    A = sparse.csr_matrix((vals, (rows, cols)), shape=(n_nodes, n_nodes))
    return A, b
