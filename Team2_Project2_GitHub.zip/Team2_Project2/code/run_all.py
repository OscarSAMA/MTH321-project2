"""Reproduce all tables and numerical figures used in the final submission.

Run from the submission root with::

    python code/run_all.py

or from this directory with::

    python run_all.py
"""

from __future__ import annotations

import csv
import os
from pathlib import Path
import subprocess
import sys


HERE = Path(__file__).resolve().parent
FIGURE_DIR = HERE / "figures"

SCRIPTS = (
    "smoke_test.py",
    "run_refinement.py",
    "run_tighten.py",
    "make_figures.py",
)

EXPECTED_OUTPUTS = (
    HERE / "refinement_table.csv",
    HERE / "tighten_residual.csv",
    FIGURE_DIR / "convergence_l2.png",
    FIGURE_DIR / "solution_and_error.png",
    FIGURE_DIR / "sparsity_pattern.png",
    FIGURE_DIR / "tolerance_sweep.png",
    FIGURE_DIR / "tighten_residual_before_after.png",
)


def run_script(filename: str) -> None:
    print(f"\n{'=' * 72}\nRunning {filename}\n{'=' * 72}", flush=True)
    environment = os.environ.copy()
    environment["MPLBACKEND"] = "Agg"
    subprocess.run(
        [sys.executable, str(HERE / filename)],
        cwd=HERE,
        env=environment,
        check=True,
    )


def validate_outputs() -> None:
    missing = [path for path in EXPECTED_OUTPUTS if not path.is_file() or path.stat().st_size == 0]
    if missing:
        names = "\n".join(f"  - {path}" for path in missing)
        raise RuntimeError(f"Missing or empty generated outputs:\n{names}")

    with (HERE / "refinement_table.csv").open(encoding="utf-8", newline="") as stream:
        refinement = list(csv.DictReader(stream))
    if len(refinement) != 16:
        raise RuntimeError(f"Expected 16 refinement rows, found {len(refinement)}")
    if {int(row["N"]) for row in refinement} != {8, 16, 32, 64}:
        raise RuntimeError("The refinement CSV does not contain all four required meshes")

    with (HERE / "tighten_residual.csv").open(encoding="utf-8", newline="") as stream:
        sweep = list(csv.DictReader(stream))
    if len(sweep) != 5 or any(int(row["info"]) != 0 for row in sweep):
        raise RuntimeError("The tolerance sweep is incomplete or contains a failed GMRES solve")

    residuals = [float(row["achieved_residual"]) for row in sweep]
    if not all(next_value < value for value, next_value in zip(residuals, residuals[1:])):
        raise RuntimeError("Achieved residuals did not decrease as the requested tolerance tightened")

    print("\nReproduction checks passed:")
    print("  - 16 refinement rows across N=8,16,32,64")
    print("  - 5 successful GMRES tolerance runs")
    print(f"  - {len(EXPECTED_OUTPUTS) - 2} report figures regenerated at 300 dpi")


def main() -> None:
    FIGURE_DIR.mkdir(exist_ok=True)
    for output in EXPECTED_OUTPUTS:
        if output.suffix.lower() == ".png" and output.exists():
            output.unlink()
    for script in SCRIPTS:
        run_script(script)
    validate_outputs()


if __name__ == "__main__":
    main()
