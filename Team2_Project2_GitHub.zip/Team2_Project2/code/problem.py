"""
Problem definition for Project 2, Direction 2: mixed-boundary Poisson.

Model:
    -Delta u = f                     in Omega = (0,1)^2
    u = g                            on Gamma_D (x=0, y=0, y=1, all corners)
    d_n u = q                        on Gamma_B (right edge, Neumann variant)
    d_n u + beta u = r               on Gamma_B (right edge, Robin variant)

Manufactured solution:  u_*(x,y) = exp(x+y),  f = -2 exp(x+y).
Node indexing:          k = j*(N+1) + i,  with x_i = i*h, y_j = j*h.
"""

import numpy as np

# Robin coefficient prescribed in the problem pack.
BETA = 2.0


def make_grid(N):
    """Return mesh spacing h and coordinate arrays X[i,j], Y[i,j] (ij indexing)."""
    h = 1.0 / N
    coords = np.linspace(0.0, 1.0, N + 1)
    X, Y = np.meshgrid(coords, coords, indexing="ij")
    return h, X, Y


def u_exact(X, Y):
    """Manufactured solution u_* = exp(x+y)."""
    return np.exp(X + Y)


def forcing(X, Y):
    """Right-hand side f = -Delta u_* = -2 exp(x+y)."""
    return -2.0 * np.exp(X + Y)


def dirichlet_value(x, y):
    """Boundary data g = u_* on the Dirichlet edges."""
    return np.exp(x + y)


def neumann_flux(y):
    """Prescribed outward normal derivative q(y) = exp(1+y) on x=1."""
    return np.exp(1.0 + y)


def robin_rhs(y):
    """Prescribed Robin data r(y) = 3 exp(1+y), with beta = 2."""
    return 3.0 * np.exp(1.0 + y)


def node_index(i, j, N):
    """Flat index of node (i,j)."""
    return j * (N + 1) + i


def is_dirichlet(i, j, N):
    """True if node lies on Gamma_D: x=0, y=0, or y=1 (includes all corners)."""
    return (i == 0) or (j == 0) or (j == N)
