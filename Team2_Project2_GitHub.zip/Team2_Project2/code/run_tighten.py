"""
Week 8 Individual Challenge — Tighten the residual.

Finest mesh N=64, Neumann data, second-order ghost-point closure.
GMRES is preconditioned with incomplete LU so that it converges in a practical
number of iterations. A tolerance sweep first locates the plateau where the
reported discretisation error stops changing. The before/after pair used for the
challenge sits on that plateau and is one order of magnitude apart in terms of
the achieved residual:

    before: rtol = 1e-9   (achieved residual ~6.9e-10)
    after:  rtol = 1e-10  (achieved residual ~6.6e-11)

The residual drops by ~10x while the L2/Linf discretisation errors are
effectively unchanged, demonstrating that the algebraic error is negligible
relative to the discretisation error at both tolerances.
"""

import csv
import os

import numpy as np

from assembler import assemble
from errors import l2_error, linf_error, to_grid
from problem import make_grid
from solvers import (
    build_preconditioner,
    relative_residual,
    solve_direct,
    solve_iter,
)

N = 64
BOUNDARY = "neumann"
CLOSURE = "ghost"
SWEEP = [1e-6, 1e-8, 1e-9, 1e-10, 1e-12]
BEFORE, AFTER = 1e-9, 1e-10

h, X, Y = make_grid(N)
A, b = assemble(N, boundary=BOUNDARY, closure=CLOSURE)
M = build_preconditioner(A)
u_direct = solve_direct(A, b)

print(f"Finest mesh N={N}, h={h:.5f}, {BOUNDARY}, {CLOSURE} closure "
      f"(ILU-preconditioned GMRES)")
print("=" * 92)
print(f"{'rtol':>8} {'achieved residual':>18} {'iters':>6} {'L2 error':>12} "
      f"{'Linf error':>12} {'diff vs direct':>15}")
print("-" * 92)

sweep_rows = []
for rtol in SWEEP:
    x, niter, info = solve_iter(A, b, rtol=rtol, M=M)
    res = relative_residual(A, b, x)
    U = to_grid(x, N)
    e2, ei = l2_error(U, X, Y, h), linf_error(U, X, Y)
    diff = float(np.linalg.norm(x - u_direct) / np.linalg.norm(u_direct))
    sweep_rows.append([rtol, res, niter, info, e2, ei, diff])
    print(f"{rtol:>8.0e} {res:>18.3e} {niter:>6d} {e2:>12.4e} {ei:>12.4e} "
          f"{diff:>15.2e}")

print("=" * 92)
before = next(r for r in sweep_rows if r[0] == BEFORE)
after = next(r for r in sweep_rows if r[0] == AFTER)

print("BEFORE/AFTER PAIR (one order of magnitude):")
print(f"  residual : {before[1]:.3e}  ->  {after[1]:.3e}  "
      f"(factor {before[1]/after[1]:.2f})")
print(f"  iters    : {before[2]} -> {after[2]}")
print(f"  L2 error : {before[4]:.4e} -> {after[4]:.4e}  "
      f"(relative change {abs(after[4]-before[4])/before[4]:.2e})")
print(f"  Linf err : {before[5]:.4e} -> {after[5]:.4e}  "
      f"(relative change {abs(after[5]-before[5])/before[5]:.2e})")
print("The discretisation errors are unchanged: tightening the residual by one "
      "order buys no extra accuracy, so the algebraic error is negligible.")

out = os.path.join(os.path.dirname(__file__), "tighten_residual.csv")
with open(out, "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["rtol", "achieved_residual", "gmres_iters", "info",
                "L2_error", "Linf_error", "diff_vs_direct"])
    w.writerows(sweep_rows)
print("Saved:", out)
