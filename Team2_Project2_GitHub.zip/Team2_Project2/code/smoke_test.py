"""Quick smoke test on a coarse grid (N=8)."""

import numpy as np

from assembler import assemble
from errors import l2_error, linf_error, to_grid
from problem import make_grid
from solvers import relative_residual, solve_direct

N = 8
h, X, Y = make_grid(N)

for boundary in ("neumann", "robin"):
    for closure in ("first", "ghost"):
        A, b = assemble(N, boundary=boundary, closure=closure)
        u = solve_direct(A, b)
        U = to_grid(u, N)
        res = relative_residual(A, b, u)
        print(
            f"{boundary:7s} {closure:5s} | shape={A.shape} nnz={A.nnz:5d} "
            f"res={res:.2e} L2={l2_error(U, X, Y, h):.4e} "
            f"Linf={linf_error(U, X, Y):.4e}"
        )
