# Code review record

## Review scope

The final code was reviewed against the MTH321 Project 2 correctness and clarity checklist and executed through `run_all.py` in an isolated Python 3.12 environment.

## Findings

| Severity | Location | Finding | Resolution |
|---|---|---|---|
| Major | package root | No portable end-to-end entry point | Added `run_all.py` with exact-output cleanup and validation |
| Major | package root | No dependency and reproduction documentation | Added `README.md` and `requirements.txt` |
| Minor | `run_refinement.py` | Asymmetry diagnostic converted sparse matrices to dense arrays | Replaced with `scipy.sparse.linalg.norm` |
| Minor | `make_figures.py` | Only two 200 dpi figures were generated | Added convergence, field/error and sparsity figures; all five save at 300 dpi |

## Checks passed

- The positive `-Delta` sign, forcing, outward-normal Neumann data and Robin data agree across model, assembly and report.
- The five-point interior row and both right-boundary closures match the documented formulas.
- Dirichlet neighbour terms move to the right-hand side with the opposite sign.
- Assembly uses sparse coordinate lists and CSR conversion.
- Refinement results show near-first-order and near-second-order behaviour as claimed.
- The GMRES stopping evidence uses the scaled residual, not iterate differences.
- All five tolerance solves return `info=0`.

## Positive feature

The separation between problem data, sparse assembly, solvers, error norms and experiment drivers makes the numerical claims straightforward to reproduce and audit.

## Remaining scientific limitation

The evidence covers a smooth manufactured solution on a uniform square grid up to 4225 unknowns. It does not establish behaviour for singular solutions, coefficient jumps, irregular domains or different ILU parameters.
