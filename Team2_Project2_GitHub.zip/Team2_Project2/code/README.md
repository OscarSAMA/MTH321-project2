# MTH321 Project 2: Mixed-Boundary Poisson Problem

Team 2: Sirui Li (2141723), Yuxuan Li (2363599), Yuran Zhou (2363402), and Yazhi Xue (2255842).

## Problem and method

The code solves

```text
-Delta u = f                     in Omega=(0,1)^2,
u = g                            on x=0, y=0, and y=1,
d_n u = q                        on x=1 for the Neumann variant,
d_n u + beta u = r               on x=1 for the Robin variant.
```

The manufactured solution is `u*(x,y)=exp(x+y)`, so the exact forcing and boundary data are known. The interior uses the five-point finite-difference stencil. The right boundary can use either a first-order backward derivative or a second-order ghost-point closure. The flat index is `k = j*(N+1) + i`.

The code assembles the matrix directly in sparse COO form and converts it to CSR. Refinement runs use SciPy's sparse direct solver. The tolerance experiment uses incomplete-LU-preconditioned GMRES and reports the independently evaluated scaled residual `||b-Au||_2/||b||_2`.

## Requirements

- Python 3.10 or later
- NumPy
- SciPy
- Matplotlib

`scikit-fem` and `pyamg` are not required: this submission uses finite differences and SciPy's `spilu` preconditioner.

Create an isolated environment and install the dependencies:

```text
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r code/requirements.txt
```

On macOS or Linux, activate with `source .venv/bin/activate`.

## One-command reproduction

From the submission root run:

```text
python code/run_all.py
```

If this directory itself is the working directory, run `python run_all.py` instead. The command performs a coarse smoke test, rebuilds both CSV tables, runs the complete GMRES tolerance sweep, regenerates all five numerical figures at 300 dpi, and validates the expected row counts and solver status flags.

## Outputs and how to reproduce them

| Output | Reproduction step | Purpose |
|---|---|---|
| `refinement_table.csv` | `python code/run_refinement.py` | Four meshes for Neumann/Robin and first/ghost closures |
| `tighten_residual.csv` | `python code/run_tighten.py` | Five-tolerance GMRES sweep on the N=64 Neumann ghost system |
| `figures/convergence_l2.png` | `python code/make_figures.py` after the CSV runs | Named-norm convergence comparison and fitted orders |
| `figures/solution_and_error.png` | same command | N=64 numerical field, sampled grid nodes, and absolute nodal error |
| `figures/sparsity_pattern.png` | same command | Sparse-matrix pattern for N=16 |
| `figures/tolerance_sweep.png` | same command | Residual reduction and discretisation-error plateau |
| `figures/tighten_residual_before_after.png` | same command | One-order tolerance tightening comparison |

`run_all.py` deletes only these generated PNG files before rebuilding them, so stale figures cannot pass the final output check.

## File structure

| File | Purpose |
|---|---|
| `problem.py` | Domain, grid, manufactured solution, PDE and boundary data, index map |
| `assembler.py` | Sparse interior and boundary-row assembly |
| `solvers.py` | Sparse direct solve, ILU and GMRES, scaled residual |
| `errors.py` | Grid reshape, discrete L2 and nodal maximum errors, observed order |
| `run_refinement.py` | Four-mesh verification study and sparse asymmetry diagnostic |
| `run_tighten.py` | Solver-tolerance sweep and before/after comparison |
| `make_figures.py` | All report figures |
| `smoke_test.py` | Quick shape, sparsity, residual and error check |
| `run_all.py` | Portable end-to-end reproduction and validation entry point |

## Reference results

At N=64, the ghost closure gives L2 errors `1.4227e-5` for Neumann data and `8.2209e-6` for Robin data, with finest-step observed orders about 2.05 and 2.06. Tightening GMRES from `rtol=1e-9` to `1e-10` reduces the achieved residual by a factor of 10.36 while adding ten iterations; the L2 and maximum discretisation errors change by less than `3.1e-4` relatively.

## Reproducibility notes

- The project has no random elements, so no random seed is required.
- All paths are relative to the location of the code directory.
- The generated CSV and PNG files are deliberately included so results can be inspected without running the code, but `run_all.py` overwrites them during reproduction.
- The supplied evidence covers a smooth manufactured solution on a uniform square grid. It does not establish behaviour for singular solutions, coefficient jumps, irregular domains, or different ILU settings.
