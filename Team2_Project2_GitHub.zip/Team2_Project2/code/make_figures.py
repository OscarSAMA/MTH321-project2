"""
Generate every numerical figure used by the final report.

Outputs (in figures/):
  convergence_l2.png                -- four-mesh L2 refinement comparison
  solution_and_error.png            -- N=64 numerical field and nodal error
  sparsity_pattern.png               -- sparse matrix pattern for a small grid
  tighten_residual_before_after.png  -- before/after comparison (main figure)
  tolerance_sweep.png                -- full tolerance sweep showing the plateau
"""

import csv
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from assembler import assemble
from errors import to_grid
from problem import make_grid, u_exact
from solvers import solve_direct

HERE = os.path.dirname(__file__)
FIGURES = os.path.join(HERE, "figures")
os.makedirs(FIGURES, exist_ok=True)


# Read the refinement study.
with open(os.path.join(HERE, "refinement_table.csv"), encoding="utf-8") as f:
    refinement_rows = list(csv.DictReader(f))

# Read the CSV with the standard library.
with open(os.path.join(HERE, "tighten_residual.csv"), encoding="utf-8") as f:
    reader = csv.DictReader(f)
    rows = []
    for r in reader:
        rows.append({
            "rtol": float(r["rtol"]),
            "residual": float(r["achieved_residual"]),
            "iters": int(r["gmres_iters"]),
            "L2": float(r["L2_error"]),
            "Linf": float(r["Linf_error"]),
        })

rtols = np.array([r["rtol"] for r in rows])
residuals = np.array([r["residual"] for r in rows])
l2_all = np.array([r["L2"] for r in rows])
linf_all = np.array([r["Linf"] for r in rows])


def get_row(tol):
    return next(r for r in rows if r["rtol"] == tol)


BEFORE_RTOL, AFTER_RTOL = 1e-9, 1e-10
before = get_row(BEFORE_RTOL)
after = get_row(AFTER_RTOL)

plt.rcParams.update({
    "font.size": 11,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.alpha": 0.3,
})

# ---------------------------------------------------------------------------
# Figure 1: four-mesh convergence evidence
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8.2, 5.2))
styles = {
    ("neumann", "first"): ("#c0504d", "o", "-", "Neumann first"),
    ("neumann", "ghost"): ("#4f81bd", "s", "-", "Neumann ghost"),
    ("robin", "first"): ("#f79646", "^", "--", "Robin first"),
    ("robin", "ghost"): ("#5b8c4a", "D", "--", "Robin ghost"),
}
for key, (color, marker, linestyle, label) in styles.items():
    rows_for_case = [r for r in refinement_rows
                     if (r["boundary"], r["closure"]) == key]
    rows_for_case.sort(key=lambda r: int(r["N"]))
    h_values = np.array([float(r["h"]) for r in rows_for_case])
    errors = np.array([float(r["L2_error"]) for r in rows_for_case])
    fitted_order = np.polyfit(np.log(h_values), np.log(errors), 1)[0]
    ax.loglog(h_values, errors, color=color, marker=marker,
              linestyle=linestyle, linewidth=2, markersize=6,
              label=f"{label}, fitted p={fitted_order:.2f}")

ax.set_xlabel("mesh spacing h")
ax.set_ylabel("discrete L2 error")
ax.set_title("Four-mesh manufactured-solution refinement study")
ax.legend(frameon=False, fontsize=9)
fig.tight_layout()
convergence_path = os.path.join(FIGURES, "convergence_l2.png")
fig.savefig(convergence_path, dpi=300, bbox_inches="tight")
plt.close(fig)

# ---------------------------------------------------------------------------
# Figure 2: numerical solution and pointwise error on the finest mesh
# ---------------------------------------------------------------------------
N_FIELD = 64
h_field, X, Y = make_grid(N_FIELD)
A_field, b_field = assemble(N_FIELD, boundary="neumann", closure="ghost")
U = to_grid(solve_direct(A_field, b_field), N_FIELD)
error = np.abs(U - u_exact(X, Y))

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10.5, 4.5), constrained_layout=True)
field_plot = ax1.contourf(X, Y, U, levels=24, cmap="viridis")
stride = 4
ax1.scatter(X[::stride, ::stride], Y[::stride, ::stride], s=2,
            color="white", alpha=0.55, label="every fourth grid node")
ax1.set_title("Numerical solution, N=64")
ax1.set_xlabel("x")
ax1.set_ylabel("y")
ax1.set_aspect("equal")
ax1.legend(frameon=False, fontsize=8, loc="lower right")
fig.colorbar(field_plot, ax=ax1, label="solution value")

error_plot = ax2.contourf(X, Y, error, levels=24, cmap="magma")
ax2.set_title("Absolute nodal error")
ax2.set_xlabel("x")
ax2.set_ylabel("y")
ax2.set_aspect("equal")
fig.colorbar(error_plot, ax=ax2, label="absolute error")
solution_path = os.path.join(FIGURES, "solution_and_error.png")
fig.savefig(solution_path, dpi=300, bbox_inches="tight")
plt.close(fig)

# ---------------------------------------------------------------------------
# Figure 3: sparse matrix evidence
# ---------------------------------------------------------------------------
A_spy, _ = assemble(16, boundary="neumann", closure="ghost")
fig, ax = plt.subplots(figsize=(6.2, 6.0))
ax.spy(A_spy, markersize=1.5, color="#17324d")
ax.set_title(f"Sparse pattern, N=16: {A_spy.shape[0]} rows, {A_spy.nnz} nonzeros")
ax.set_xlabel("column index")
ax.set_ylabel("row index")
fig.tight_layout()
sparsity_path = os.path.join(FIGURES, "sparsity_pattern.png")
fig.savefig(sparsity_path, dpi=300, bbox_inches="tight")
plt.close(fig)

# ---------------------------------------------------------------------------
# Figure 1: before/after comparison
# ---------------------------------------------------------------------------
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.6))

# Left: achieved residual.
labels = ["before\nrtol=1e-9", "after\nrtol=1e-10"]
res_vals = [before["residual"], after["residual"]]
bars = ax1.bar(labels, res_vals, color=["#c0504d", "#4f81bd"], width=0.55)
ax1.set_yscale("log")
ax1.set_ylabel("achieved relative residual")
ax1.set_title("(a) Solver residual")
ax1.set_ylim(bottom=5e-11, top=res_vals[0] * 1.8)
for b, v in zip(bars, res_vals):
    ax1.text(b.get_x() + b.get_width() / 2, v * 1.15, f"{v:.2e}",
             ha="center", va="bottom", fontsize=10)
ax1.annotate("", xy=(1, after["residual"]),
             xytext=(0, before["residual"]),
             arrowprops=dict(arrowstyle="->", color="gray", lw=1.4))
ax1.text(0.5, 3e-11, f"{before['residual']/after['residual']:.1f}x lower",
         ha="center", color="gray", fontsize=10)

# Right: discretisation errors (L2 and Linf), before vs after.
x = np.arange(2)
width = 0.35
l2 = [before["L2"], after["L2"]]
li = [before["Linf"], after["Linf"]]
b1 = ax2.bar(x - width / 2, l2, width, label="L2 error", color="#9bbb59")
b2 = ax2.bar(x + width / 2, li, width, label="Linf error", color="#f79646")
ax2.set_yscale("log")
ax2.set_xticks(x)
ax2.set_xticklabels(labels)
ax2.set_ylabel("discretisation error")
ax2.set_title("(b) Reported discretisation error")
ax2.set_ylim(bottom=8e-6, top=max(li) * 1.9)
ax2.legend(frameon=False, loc="lower right")
for bars_ in (b1, b2):
    for b in bars_:
        v = b.get_height()
        ax2.text(b.get_x() + b.get_width() / 2, v * 1.08, f"{v:.2e}",
                 ha="center", va="bottom", fontsize=8.5)

fig.suptitle("Tightening the residual by one order: residual drops 10x, "
             "discretisation error stays on the plateau", y=1.02)
fig.tight_layout()
out1 = os.path.join(FIGURES, "tighten_residual_before_after.png")
fig.savefig(out1, dpi=300, bbox_inches="tight")
plt.close(fig)

# ---------------------------------------------------------------------------
# Figure 2: full tolerance sweep
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8.2, 5.2))
ax.loglog(rtols, residuals, "o-", color="#c0504d",
          label="achieved residual")
ax.loglog(rtols, l2_all, "s-", color="#4f81bd", label="L2 error")
ax.loglog(rtols, linf_all, "^-", color="#f79646", label="Linf error")

ax.axvspan(BEFORE_RTOL, AFTER_RTOL, color="gray", alpha=0.15)
ax.axvline(BEFORE_RTOL, color="gray", ls=":", lw=1)
ax.axvline(AFTER_RTOL, color="gray", ls=":", lw=1)
ax.text(np.sqrt(BEFORE_RTOL * AFTER_RTOL), 2e-13, "before/after pair",
        ha="center", color="dimgray", fontsize=9)

ax.invert_xaxis()
ax.set_xlabel("requested GMRES tolerance rtol")
ax.set_ylabel("norm value")
ax.set_title("Tolerance sweep: residual keeps falling, but discretisation "
             "errors plateau for rtol <= 1e-8")
ax.legend(frameon=False)
fig.tight_layout()
out2 = os.path.join(FIGURES, "tolerance_sweep.png")
fig.savefig(out2, dpi=300, bbox_inches="tight")
plt.close(fig)

for output in (convergence_path, solution_path, sparsity_path, out1, out2):
    print("Saved:", output)
