# Final submission audit

## Three-part package

- [x] Team report PDF, at least eight pages
- [x] Code archive with README and dependency list
- [x] Slides PDF

## Report

- [x] Team number, names, and student IDs
- [x] Background, model, discretisation, implementation, verification, experiments, conclusions
- [x] PDE, square domain, boundary split, forcing and manufactured data
- [x] First-order and ghost-point Neumann/Robin rows derived and tested
- [x] Five figures with interpretive captions
- [x] Four-mesh refinement in named L2 and maximum norms with observed orders
- [x] Tolerance sweep separates scaled residual from discretisation error
- [x] Manufactured solution identified as the constructed oracle
- [x] GMRES iterations identified and reported as the cost measure
- [x] AI Transparency Log with three claim audits and independent evidence
- [x] Team-owned methods and trusted NumPy/SciPy/Matplotlib interfaces identified
- [x] One labelled ICS page included for each member
- [x] References included
- [x] Each member has a completed ICS page with a typed electronic signature and date
- [ ] Each member confirms the wording against the actual git history and adds any required commit ID

## Code

- [x] `python code/run_all.py` runs end to end
- [x] README explains dependencies, commands, outputs, and figure reproduction
- [x] No absolute paths in submission code
- [x] Problem definition, assembly, solver, error evaluation, and drivers are separated
- [x] Grid-to-vector map documented as `k=j*(N+1)+i`
- [x] Matrix assembled directly as sparse COO and converted to CSR
- [x] No random elements
- [x] Generated figures are deleted by exact name and rebuilt at 300 dpi
- [x] `.gitignore` excludes virtual environments, caches, and build artefacts
- [x] Sparse matrix asymmetry diagnostic avoids dense conversion

## Slides

- [x] Twelve-slide PDF and editable PPTX
- [x] Background, model, discretisation, verification, solver study, limitations, conclusions
- [x] Quantitative table and editable convergence chart
- [x] Scope fits a ten-minute presentation with three minutes for questions

## Reproduction record

The final packaged code completed the smoke test, regenerated 16 refinement rows over `N=8,16,32,64`, completed five successful GMRES tolerance runs, and regenerated five non-empty figures.
